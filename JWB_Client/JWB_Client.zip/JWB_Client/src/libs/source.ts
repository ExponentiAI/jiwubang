import Mon  from '../assets/images/Mon.png'
import week  from '../assets/images/week.png'
import takeout  from '../assets/images/takeout.png'
import materials  from '../assets/images/materials.png'
import materials1  from '../assets/images/materials1.png'
import sort  from '../assets/images/sort-ico.png'
import icon1  from '../assets/images/icon1.png'
import icon11  from '../assets/images/icon1-1.png'
import icon2  from '../assets/images/icon2.png'
import icon21  from '../assets/images/icon2-1.png'
import icon3  from '../assets/images/icon3.png'
import icon31  from '../assets/images/icon3-1.png'
import setIcon  from '../assets/images/set-icon.png'
import headImg  from '../assets/images/head.png'
import remind  from '../assets/images/remind.png'
import type  from '../assets/images/type.png'
import add  from '../assets/images/add.png'
import loginBg  from '../assets/images/login-bg.png'
import phone  from '../assets/images/phone.png'
import password  from '../assets/images/password.png'
import error  from '../assets/images/error.png'
import shareImage  from '../assets/images/shareImage.png'

export default {
  Mon,
  week,
  takeout,
  materials,
  materials1,
  sort,
  icon1,
  icon11,
  icon2,
  icon21,
  icon3,
  icon31,
  setIcon,
  headImg,
  remind,
  type,
  add,
  loginBg,
  phone,
  password,
  error,
  shareImage
}