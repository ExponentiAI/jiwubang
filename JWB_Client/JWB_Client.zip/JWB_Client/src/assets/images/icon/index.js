import billIco1 from './bill-ico1.png';
import billIco2 from './bill-ico2.png';
import empty from './empty.png';
import mapLocation from './map-location.png';
import reportIco1 from './report-ico1.png';
import reportIco2 from './report-ico2.png';
import infoRIco from './一级图标1.png';
import infoPIco from './一级图标2.png';
import scrollUpIco from './上滑键.png';
import scrollDownIco from './下滑键.png';

export { 
    billIco1,
    billIco2,
    empty,
    mapLocation,
    reportIco1,
    reportIco2,
    infoRIco,
    infoPIco,
    scrollUpIco,
    scrollDownIco,
 
}