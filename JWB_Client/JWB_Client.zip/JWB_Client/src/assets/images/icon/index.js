import billIco1 from './bill-ico1.png';
import billIco2 from './bill-ico2.png';
import empty from './empty.png';
import mapLocation from './map-location.png';
import reportIco1 from './report-ico1.png';
import reportIco2 from './report-ico2.png';
import scrollUpIco from './上滑键.png';
import scrollDownIco from './下滑键.png';

import aboutIcon from './Icon-guanyu.png';
import disco from './disco.png';
import bottomIcon from './logo9.png';

import tabbar_icon1 from './xxqz.png'
import tabbar_icon2 from './xxtg.png'
import tabbar_icon3 from './gywm.png'

export { 
    billIco1,
    billIco2,
    empty,
    mapLocation,
    reportIco1,
    reportIco2,
    scrollUpIco,
    scrollDownIco,
    aboutIcon,
    disco,
    bottomIcon,
    tabbar_icon1,
    tabbar_icon2,
    tabbar_icon3,
}