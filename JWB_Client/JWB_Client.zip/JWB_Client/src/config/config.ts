const dev = process.env.NODE_ENV === 'development'
const confing = {
  useMock: !true,
  baseUrl: 'https://jwb.comdesignlab.com/',
  dev
}
export default confing
